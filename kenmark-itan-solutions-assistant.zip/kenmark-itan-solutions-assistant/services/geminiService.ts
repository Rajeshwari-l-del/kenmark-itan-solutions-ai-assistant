
import { GoogleGenAI, Chat } from "@google/genai";
import { SYSTEM_INSTRUCTION } from "../constants/knowledgeBase";

const MODEL_NAME = "gemini-3-flash-preview";

export class GeminiService {
  private ai: GoogleGenAI;
  private chat: Chat | null = null;

  constructor() {
    const apiKey = process.env.API_KEY || '';
    this.ai = new GoogleGenAI({ apiKey });
  }

  private initChat() {
    if (!this.chat) {
      this.chat = this.ai.chats.create({
        model: MODEL_NAME,
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
          temperature: 0.1, // Keep it deterministic for factual accuracy
          topP: 0.95,
        },
      });
    }
    return this.chat;
  }

  async sendMessage(message: string) {
    try {
      const chat = this.initChat();
      const response = await chat.sendMessage({ message });
      return response.text || "I’m sorry, I’m having trouble connecting right now.";
    } catch (error) {
      console.error("Gemini API Error:", error);
      return "I’m sorry, I encountered an error. Please try again later.";
    }
  }

  async sendMessageStream(message: string, onChunk: (chunk: string) => void) {
    try {
      const chat = this.initChat();
      const result = await chat.sendMessageStream({ message });
      
      let fullText = "";
      for await (const chunk of result) {
        const text = chunk.text || "";
        fullText += text;
        onChunk(text);
      }
      return fullText;
    } catch (error) {
      console.error("Gemini Streaming Error:", error);
      throw error;
    }
  }
}

export const geminiService = new GeminiService();
