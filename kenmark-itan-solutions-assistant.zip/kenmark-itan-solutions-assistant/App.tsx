
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Message } from './types';
import { geminiService } from './services/geminiService';
import ChatMessage from './components/ChatMessage';

const SUGGESTED_QUESTIONS = [
  "What services do you offer?",
  "How can I contact Kenmark ITan?",
  "Tell me about your AI solutions.",
  "Do you offer corporate training?"
];

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: "Hello! Welcome to Kenmark ITan Solutions. I'm your virtual assistant. How can I help you today?",
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, scrollToBottom]);

  const handleSend = async (text: string = input) => {
    if (!text.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: text,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const assistantId = (Date.now() + 1).toString();
      const assistantMessage: Message = {
        id: assistantId,
        role: 'assistant',
        content: '',
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMessage]);

      let accumulatedText = '';
      await geminiService.sendMessageStream(text, (chunk) => {
        accumulatedText += chunk;
        setMessages(prev => 
          prev.map(msg => msg.id === assistantId ? { ...msg, content: accumulatedText } : msg)
        );
      });

    } catch (error) {
      setMessages(prev => [
        ...prev,
        {
          id: 'error-' + Date.now(),
          role: 'assistant',
          content: "I’m sorry, I’m having trouble connecting right now. Please try again.",
          timestamp: new Date()
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex flex-col h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 py-4 px-6 flex items-center justify-between sticky top-0 z-10 shadow-sm">
        <div className="flex items-center space-x-3">
          <div className="bg-blue-600 p-2 rounded-lg">
            <i className="fa-solid fa-code text-white"></i>
          </div>
          <div>
            <h1 className="font-bold text-slate-800 tracking-tight leading-none">Kenmark ITan Solutions</h1>
            <p className="text-xs text-blue-600 font-medium mt-1 uppercase tracking-widest">Virtual Assistant</p>
          </div>
        </div>
        <div className="hidden sm:flex items-center space-x-4">
          <a href="https://kenmarkitan.com" target="_blank" rel="noopener noreferrer" className="text-sm text-slate-500 hover:text-blue-600 font-medium transition-colors">
            Main Website <i className="fa-solid fa-arrow-up-right-from-square ml-1 text-[10px]"></i>
          </a>
        </div>
      </header>

      {/* Main Chat Area */}
      <main className="flex-1 overflow-y-auto p-4 sm:p-6 chat-scrollbar">
        <div className="max-w-4xl mx-auto">
          {messages.map((msg) => (
            <ChatMessage key={msg.id} message={msg} />
          ))}
          {isLoading && messages[messages.length - 1].content === '' && (
            <div className="flex items-center space-x-2 text-slate-400 text-sm ml-11 mb-4">
              <i className="fa-solid fa-circle-notch fa-spin"></i>
              <span>Assistant is typing...</span>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </main>

      {/* Footer / Input Area */}
      <footer className="bg-white border-t border-slate-200 p-4 sm:p-6 sticky bottom-0">
        <div className="max-w-4xl mx-auto">
          {/* Quick Suggestions */}
          <div className="flex flex-wrap gap-2 mb-4">
            {SUGGESTED_QUESTIONS.map((q, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(q)}
                disabled={isLoading}
                className="text-xs bg-slate-100 hover:bg-blue-50 text-slate-600 hover:text-blue-600 border border-slate-200 hover:border-blue-200 px-3 py-1.5 rounded-full transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {q}
              </button>
            ))}
          </div>

          {/* Input Box */}
          <div className="relative group">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyPress}
              placeholder="Type your question about Kenmark ITan Solutions..."
              rows={1}
              className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-3 pr-16 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all resize-none text-sm"
              disabled={isLoading}
            />
            <button
              onClick={() => handleSend()}
              disabled={!input.trim() || isLoading}
              className="absolute right-2 top-1/2 -translate-y-1/2 bg-blue-600 hover:bg-blue-700 text-white w-10 h-10 rounded-xl flex items-center justify-center transition-all disabled:opacity-40 disabled:bg-slate-400 group-focus-within:shadow-lg"
            >
              {isLoading ? (
                <i className="fa-solid fa-spinner fa-spin"></i>
              ) : (
                <i className="fa-solid fa-paper-plane"></i>
              )}
            </button>
          </div>
          <p className="text-[10px] text-center text-slate-400 mt-3">
            Only answers questions based on Kenmark ITan Solutions official knowledge base.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default App;
